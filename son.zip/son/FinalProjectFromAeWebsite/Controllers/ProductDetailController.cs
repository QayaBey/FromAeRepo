﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FinalProjectFromAeWebsite.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FinalProjectFromAeWebsite.Controllers
{
    public class ProductDetailController : Controller
    {
        public FromAeDbContext _dbContext;

        public ProductDetailController(FromAeDbContext dbContext)
        {
            _dbContext = dbContext;
        }
        public IActionResult ProductDetails(int id)
        {
            ViewBag.Name = _dbContext.Products.Where(x => x.Id == id).Select(x => x.Name).ToList();
            ViewBag.Category = (from m in _dbContext.Markas
                                  join mo in _dbContext.Models
                      on m.Id equals mo.MarkaId
                                  join p in _dbContext.Products on mo.Id equals p.ModelId
                                  join pc in _dbContext.ProductCategories on p.Id equals pc.ProductId
                                  join c in _dbContext.Categories on pc.CategoryId equals c.Id
                                  where p.Id == id
                                  select c.Name).Distinct();
            ViewBag.SubMenu = (from p in _dbContext.Products
                               join pc in _dbContext.ProductCategories on p.Id equals pc.ProductId
                               join c in _dbContext.Categories on pc.CategoryId equals c.Id
                               join sb in _dbContext.SubMenus on c.SubMenuId equals sb.Id
                               join m in _dbContext.Menus on sb.MenuId equals m.Id
                               where p.Id == id
                               select sb.Name).ToList();
            ViewBag.Menu = (from p in _dbContext.Products
                               join pc in _dbContext.ProductCategories on p.Id equals pc.ProductId
                               join c in _dbContext.Categories on pc.CategoryId equals c.Id
                               join sb in _dbContext.SubMenus on c.SubMenuId equals sb.Id
                               join m in _dbContext.Menus on sb.MenuId equals m.Id
                               where p.Id == id
                               select m.Name).ToList();

            ViewBag.Price = _dbContext.Products.Where(x => x.Id == id).Select(x => x.Price).ToList();
            ViewBag.Discount = _dbContext.Products.Where(x => x.Id == id).Select(x => x.Discount).ToList();
            ViewBag.SalePrice = _dbContext.Products.Where(x => x.Id == id).Select(x => x.SalePrice).ToList();
            ViewBag.Istehsalci = (from m in _dbContext.Markas
                                  join mo in _dbContext.Models
                                  on m.Id equals mo.MarkaId
                                  join p in _dbContext.Products on mo.Id equals p.ModelId
                                   where p.Id == id
                                  select m.Name).Distinct();

            ViewBag.Image = _dbContext.Pictures.Include(x => x.Product).Where(x => x.ProductId == id).Select(x => x.MainImg).ToList();
            ViewBag.PropName = _dbContext.ProductProperties.Where(x => x.ProductId == id).Select(x => x.Property.Name).ToList();
            ViewBag.PropValue = _dbContext.ProductProperties.Where(x => x.ProductId == id).Select(x => x.Value).ToList();
            var product = _dbContext.Products.Where(x => x.Id== id);
            return View(product);
        }
    }
}